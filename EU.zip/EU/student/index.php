<?php
session_start();
$connection = mysqli_connect('localhost', 'root', '', 'college_admission');
if (!isset($_SESSION["username"])) {
    header("Location: ../login/index.php");
} elseif (isset($_SESSION['admin'])) {
    header("Location: ../admin/index.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Empress University</title>
    <link href="assets/img/eu.png" rel="icon">
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300i,400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <script src="./js/all.js" crossorigin="anonymous"></script>
    <style>
        body {
            padding: 0;
            margin: 0;
            font-family: "Nunito Sans";
            background-color: white;
        }

        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        p {
            margin: 0;
            text-transform: capitalize;
            font-weight: bold;
        }

        th {
            padding: 10px !important;
        }

        .k {
            font-style: bold;
            font-weight: 1000;
        }

        #j {
            background-color: green;
        }

        #jj {
            background-color: #B21807;
        }

        #kk {
            background-color: #2db6fa;
        }

        .table {
            margin-bottom: 0px;
        }

        .table>:not(caption)>*>* {
            border-color: #2db6fa;
            vertical-align: middle;
            white-space: nowrap;
        }

        .table>:not(:first-child) {
            border-top: #2db6fa;
        }

        .table>thead {
            background-color: #2db6fa;
            color: #fff;
        }

        .row {
            align-items: center;
        }

        form {
            border-radius: 10px;
            box-shadow: 5px 5px 90px 5px grey;
        }

        .form-control {
            line-height: 2;
            border: 1px solid #ddd;
            border-radius: 15px;
        }

        .form-control:focus {
            box-shadow: none;
            border-color: #2db6fa;
        }

        .form-check-input:checked {
            background-color: #2db6fa;
            border-color: #2db6fa;
        }

        .form-check-input:focus {
            box-shadow: none;
        }

        .form-control:hover {
            border-color: #2db6fa;
        }

        .btn-custom {
            border-color: #2db6fa;
            color: #2db6fa;
        }

        .btn-custom:hover {
            background-color: #2db6fa;
            color: #fff;
            box-shadow: 0 2px 4px rgb(0 0 0 / 10%), 0 8px 16px rgb(0 0 0 / 10%);
        }

        .row.m-0 {
            border-bottom: 1px solid #f4be2b;
            margin-bottom: 15px !important;
            background: #f4be2b;
            font-weight: 600;
            color: #fff;
        }

        .row.mb-2 {
            margin: 0;
        }

        .col-lg-4 p {
            font-size: 12px;
        }

        @media(max-width: 992px) {
            form {
                width: 80%;
            }
        }

        @media(max-width: 575px) {
            form {
                width: 100%;
            }
        }
    </style>
</head>


<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <!-- Navbar Brand-->
        <a class="navbar-brand ps-3" href="index.html">Empress University</a>
        <!-- Sidebar Toggle-->
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
        <!-- Navbar-->
        <ul class="navbar-nav ms-auto me-0 me-md-3 my-2 my-md-0">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="../code/logout.php">Logout</a></li>
                </ul>
            </li>
        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Core</div>
                        <a class="nav-link" href="">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                        <a class="nav-link" href="./fees.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Fees
                        </a>
                    </div>
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <?php
            $uname = $_SESSION["username"];
            $query = "SELECT * FROM `form` where `User_id`='$uname'";
            $result = $connection->query($query);
            $rows = $result->fetch_all(MYSQLI_NUM);
            if (!$rows) {
            ?>
                <main>
                    <div class="container  mt-5 mb-5">
                        <form action="./code/forminsert.php" method="POST" class="bg-light p-4 m-auto">
                            <h1 style="text-align:center;">Admission FORM</h1>
                            <h6 style="text-align:center;">(* filds are compalsory to fill)</h6><br>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>First Name *</p>
                                </div>
                                <div class="col-lg-5">
                                    <input type="text" class="form-control" placeholder="First Name" name="fname" required>
                                </div>
                                <div class="col-lg-4">
                                    <p>(max 30 characters a-z and A-Z)</p>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>Last Name *</p>
                                </div>
                                <div class="col-lg-5">
                                    <input type="text" class="form-control" placeholder="Last Name" name="lname" required>
                                </div>
                                <div class="col-lg-4">
                                    <p>(max 30 characters a-z and A-Z)</p>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>Father Name *</p>
                                </div>
                                <div class="col-lg-5">
                                    <input type="text" class="form-control" placeholder="Father Name" name="father" required>
                                </div>
                                <div class="col-lg-4">
                                    <p>(max 30 characters a-z and A-Z)</p>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>Date of Birth *</p>
                                </div>
                                <div class="col-lg-5 d-flex">
                                    <input type="date" name="dob" class="form-control" name="dob" required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>Email id </p>
                                </div>
                                <div class="col-lg-5">
                                    <input type="text" class="form-control" placeholder="Email id" name="email" required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>Student Contact Number*</p>
                                </div>
                                <div class="col-lg-5">
                                    <input type="number" name="snum" class="form-control" placeholder="Student Contact Number" required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>Parents Contact Number*</p>
                                </div>
                                <div class="col-lg-5">
                                    <input type="number" name="pnum" class="form-control" size="10" placeholder="Parents Contact Number" required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>Gender *</p>
                                </div>
                                <div class="col-lg-5 d-flex">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" value="Male">
                                        <label class="form-check-label" for="flexRadioDefault1">
                                            Male
                                        </label>
                                    </div>
                                    <div class="form-check mx-3">
                                        <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" value="Female">
                                        <label class="form-check-label" for="flexRadioDefault1">
                                            Female
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>Address *</p>
                                </div>
                                <div class="col-lg-7">
                                    <textarea class="form-control" rows="5" name="address" required></textarea>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>Pin code *</p>
                                </div>
                                <div class="col-lg-5">
                                    <input type="text" class="form-control" placeholder="Pin code" name="pin" required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>State *</p>
                                </div>
                                <div class="col-lg-5">
                                    <input type="text" class="form-control" placeholder="State" name="state" required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>City *</p>
                                </div>
                                <div class="col-lg-5">
                                    <input type="text" class="form-control" placeholder="City" name="city" required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>Country *</p>
                                </div>
                                <div class="col-lg-5">
                                    <input type="text" class="form-control" placeholder="Country" name="conutry" required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>Hobbies</p>
                                </div>
                                <div class="col-lg-5">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="Drawing" name="hobby">
                                        <label class="form-check-label" for="inlineCheckbox1">Drawing </label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="Singing" name="hobby">
                                        <label class="form-check-label" for="inlineCheckbox2">Singing </label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="Dancing" name="hobby">
                                        <label class="form-check-label" for="inlineCheckbox2">Dancing </label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="Sketching" name="hobby">
                                        <label class="form-check-label" for="inlineCheckbox2">Sketching </label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="Other" name="hobby">
                                        <label class="form-check-label" for="inlineCheckbox2">Other </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>Courses *</p>
                                </div>
                                <div class="col-lg-2 d-flex">
                                    <select name="courses" required>
                                        <option value="bcom">B.COM</option>
                                        <option value="mcom">M.COM</option>
                                        <option value="bba">BBA</option>
                                        <option value="mba">MBA</option>
                                        <option value="bca">BCA</option>
                                        <option value="mca">MCA</option>
                                        <option value="llb">LLB</option>
                                        <option value="pgdca">PG-DCA</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>Upload Results *</p>
                                </div>
                                <div class="col-lg-5 d-flex">
                                    <input type="file" accept="image/*,.pdf" name="result" multiple required>
                                </div>
                                <div class="col-lg-4">
                                    <p style="font-size:15px;">(10th AND 12th Result Both)</p>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-2">
                                    <p>Student Photo *</p>
                                </div>
                                <div class="col-lg-5 d-flex">
                                    <input type="file" accept="image/*" name="sphoto" required>
                                </div>
                            </div>
                            <!-- <button type="button"  >Send Now</button> -->
                            <input type="submit" value="Send Now" class="btn btn-custom btn-lg btn-block" style="width:100%" name="submit">
                        </form>
                </main>
        </div>
    </div>
<?php
            } else {
?>
    <main>
        <div class="container  mt-5 mb-5">
            <?php
                $pdo = new PDO("mysql:host=localhost; dbname=college_admission", "root", "");
                $uid = $_SESSION["username"];
                $query = $pdo->prepare("SELECT * FROM form WHERE User_id=?");
                $query->execute(array($uid));
                $control = $query->fetch();
                $status = $control['status'];
                if ($status == 0) {
            ?>
                <h1 class="k">Application Status </h1>
                <button class="btn btn-success" disabled style="width: 350px;" id="kk">Application is Pending...</button>
            <?php
                } else if ($status == 1) {
            ?>
                <h1 class="k">Application Status </h1>
                <button class="btn btn-success" disabled style="width: 350px;" id="j">Application is Approved</button>
            <?php
                } else {
            ?>
                <h1 class="k">Application Status </h1>
                <button class="btn btn-danger" disabled style="width: 350px;" id="jj">Application is Rejected</button>
            <?php
                }
            ?>

        </div>
    </main>
<?php
            }
?>
<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script> -->
<script src="js/scripts.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
<script src="assets/demo/chart-area-demo.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="assets/demo/chart-bar-demo.js"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
<script src="js/datatables-simple-demo.js"></script>
<script type="text/javascript">
    function preventBack() {
        window.history.forward();
    }
    setTimeout("preventBack()", 0);
    window.onunload = function() {
        null
    };
</script>
</body>


</html>