<?php
session_start();
$pdo = new PDO("mysql:host=localhost; dbname=college_admission", "root", "");
// $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
  
  if(isset($_POST["submit"])){
    $uid=$_SESSION["username"];
    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
    $father = $_POST["father"];
    $dob = $_POST["dob"];
    $email = $_POST["email"];
    $snum = $_POST["snum"];
    $pnum = $_POST["pnum"];
    $gender = $_POST["flexRadioDefault"];
    $address = $_POST["address"];
    $pin = $_POST["pin"];
    $state = $_POST["state"];
    $city = $_POST["city"];
    $conutry = $_POST["conutry"];
    $hobby = $_POST["hobby"];
    $courses = $_POST["courses"];
    $result = $_POST["result"];
    $sphoto = $_POST["sphoto"];
    // INSERT INTO `form` (`id`, `fname`, `lname`, `father`, `dob`, `email`, `snum`, `pnum`, `gender`, `address`, `pin`, `state`, `city`, `conutry`, `hobby`, `courses`, `result`, `sphoto`, `status`) VALUES (NULL, 'h', 'j', 'k', '2002-11-11', 'yo@gmail.com', '1024552254', '454874561', 'mlae', 'sdf', '361005', 'jamnagar', 'jamnagar', 'gujrat', 'other', 'bca', 'cx', 'zxc', '1');
    $query=$pdo->prepare("INSERT INTO form (User_id,fname,lname,father,dob,email,snum,pnum,gender,address,pin,state,city,conutry,hobby,courses,result,sphoto)
                          VALUES (:uid,:fname,:lname,:father,:dob,:email,:snum,:pnum,:flexRadioDefault,:address,:pin,:state,:city,:conutry,:hobby,:courses,:result,:sphoto)");
    $data=$query->execute([':uid'=>$uid,':fname'=>$fname,':lname'=>$lname,':father'=>$father,':dob'=>$dob,':email'=>$email,':snum'=>$snum,':pnum'=>$pnum,':flexRadioDefault'=>$gender,':address'=>$address,':pin'=>$pin,':state'=>$state,':city'=>$city,':conutry'=>$conutry,':hobby'=>$hobby,':courses'=>$courses,':result'=>$result,':sphoto'=>$sphoto]);
    echo ("<script LANGUAGE='JavaScript'>
    window.alert('Submited Sucessfully');
    window.location.href='../index.php';
    </script>");

    }
    
 ?>