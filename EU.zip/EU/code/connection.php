<?php
    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "college_admission";

    $pdo = new PDO("mysql:host=localhost;dbname=college_admission", "root", "");

?>