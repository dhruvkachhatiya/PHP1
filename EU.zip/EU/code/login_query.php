<?php

  session_start();
  try{
  $pdo = new PDO("mysql:host=localhost; dbname=college_admission", "root", "");
    if(isset($_POST["login_button"])){
      if($_POST["username"] == "" or $_POST["password"] == ""){

        echo ("<script LANGUAGE='JavaScript'>
              window.alert('Username and Password can not be empty.');
              window.location.href='../login/';
              </script>");

      }
      else{

        $username=$_POST["username"];
        $password=$_POST["password"];
        $query=$pdo->prepare("SELECT * FROM users WHERE username=? AND password=? ");
        $query->execute(array($username,$password));
        $control=$query->fetch();
        $id=$control['id'];
        if($username == 'admin' and $password == 'admin'){
          $_SESSION["admin"]="admin";
          header("Location:../admin/");
        }
        elseif($control > 0){
          $_SESSION["username"]=$id;
          header("Location:../student/");
        }
        echo ("<script LANGUAGE='JavaScript'>
        window.alert('Username and Password is wrong.');
        window.location.href='../login/index.php';
        </script>");
      }
    }
  }
 
  catch(PDOException $e){
    echo $e->getMessage("Connection failed");
  }
