<?php

session_start();

$pdo = new PDO("mysql:host=localhost; dbname=college_admission", "root", "");
// $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

  if(isset($_POST["signupbutton"])){
    if($_POST["username"] == "" or $_POST["email"] == "" or $_POST["password"] == "")
    {
      echo ("<script LANGUAGE='JavaScript'>
              window.alert('username,email and password can not be empty.');
              window.location.href='../login/index.php';
              </script>");
    }

    else{
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    $query=$pdo->prepare("INSERT INTO users (username, email, password) VALUES (:username,:email,:password)");
    $data=$query->execute([':username'=>$username,':email'=>$email,':password'=>$password]);

    echo ("<script LANGUAGE='JavaScript'>
    window.alert('signup sucessfully');
    window.location.href='../login/index.php';
    </script>");

    }
    header("Loction:../login/index.php");
      
    }
    
 ?>