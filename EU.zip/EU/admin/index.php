<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: ../login/");
}
// $pdo = new PDO("mysql:host=localhost; dbname=college_admission", "root", "");
$connection = mysqli_connect('localhost', 'root', '', 'college_admission');
$query = "SELECT * FROM `form` where status='0'";
$result = $connection->query($query);
$rows = $result->fetch_all(MYSQLI_NUM);
$query1 = "SELECT * FROM `form` where status='1'";
$result1 = $connection->query($query1);
$rows1 = $result1->fetch_all(MYSQLI_NUM);
$query2 = "SELECT * FROM `form` where status='2'";
$result2 = $connection->query($query2);
$rows2 = $result2->fetch_all(MYSQLI_NUM);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Empress University</title>
    <link href="assets/img/eu.png" rel="icon">
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300i,400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <script src="./js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <!-- Navbar Brand-->
        <a class="navbar-brand ps-3" href="index.html">Empress University</a>
        <!-- Sidebar Toggle-->
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
        <!-- Navbar-->
        <ul class="navbar-nav ms-auto me-0 me-md-3 my-2 my-md-0">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="../code/logout.php">Logout</a></li>
                </ul>
            </li>
        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading"></div>
                        <a class="nav-link" href="">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Requests
                        </a>
                        <a class="nav-link" href="./users.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                            Users
                        </a>
                    </div>
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container mt-5 mb-5">
                    <h1>Panding</h1>
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive m-t-40">
                                <table class="table table-bordered table-striped">
                                    <thead>

                                        <tr>

                                            <th>fname</th>
                                            <th>lname</th>
                                            <th>father</th>
                                            <th>dob</th>
                                            <th>email</th>
                                            <th>snum</th>
                                            <th>pnum</th>
                                            <th>gender</th>
                                            <th>address</th>
                                            <th>pin</th>
                                            <th>state</th>
                                            <th>city</th>
                                            <th>conutry</th>
                                            <th>hobby</th>
                                            <th>courses</th>
                                            <th>result</th>
                                            <th>sphoto</th>
                                            <th colspan="2">Action</th>
                                        </tr>
                                    </thead>

                                    <?php
                                    foreach ($rows as $r) {
                                    ?>
                                        <tbody>
                                            <tr>
                                                <td><?= $r['2'] ?></td>
                                                <td><?= $r['3'] ?></td>
                                                <td><?= $r['4'] ?></td>
                                                <td><?= $r['5'] ?></td>
                                                <td><?= $r['6'] ?></td>
                                                <td><?= $r['7'] ?></td>
                                                <td><?= $r['8'] ?></td>
                                                <td><?= $r['9'] ?></td>
                                                <td><?= $r['10'] ?></td>
                                                <td><?= $r['11'] ?></td>
                                                <td><?= $r['12'] ?></td>
                                                <td><?= $r['13'] ?></td>
                                                <td><?= $r['14'] ?></td>
                                                <td><?= $r['15'] ?></td>
                                                <td><?= $r['16'] ?></td>
                                                <td><?= $r['17'] ?></td>
                                                <td><?= $r['18'] ?></td>
                                                <td><a href="code/submit-status-apporve.php?id=<?= $r[0] ?>" class="btn btn-success">Accpect</a></td>
                                                <td><a href="code/submit-status-cancle.php?id=<?= $r[0] ?>" class="btn btn-danger">Reject</a></td>
                                            </tr>
                                        </tbody>
                                    <?php
                                    }
                                    ?>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="container mt-5 mb-5">
                    <h1>Accepted</h1>
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive m-t-40">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>

                                            <th>fname</th>
                                            <th>lname</th>
                                            <th>father</th>
                                            <th>dob</th>
                                            <th>email</th>
                                            <th>snum</th>
                                            <th>pnum</th>
                                            <th>gender</th>
                                            <th>address</th>
                                            <th>pin</th>
                                            <th>state</th>
                                            <th>city</th>
                                            <th>conutry</th>
                                            <th>hobby</th>
                                            <th>courses</th>
                                            <th>result</th>
                                            <th>sphoto</th>
                                            <th>Status</th>

                                        </tr>
                                    </thead>
                                    <?php
                                    foreach ($rows1 as $r1) {
                                    ?>
                                        <tbody>
                                            <tr>
                                                <td><?= $r1['2'] ?></td>
                                                <td><?= $r1['3'] ?></td>
                                                <td><?= $r1['4'] ?></td>
                                                <td><?= $r1['5'] ?></td>
                                                <td><?= $r1['6'] ?></td>
                                                <td><?= $r1['7'] ?></td>
                                                <td><?= $r1['8'] ?></td>
                                                <td><?= $r1['9'] ?></td>
                                                <td><?= $r1['10'] ?></td>
                                                <td><?= $r1['11'] ?></td>
                                                <td><?= $r1['12'] ?></td>
                                                <td><?= $r1['13'] ?></td>
                                                <td><?= $r1['14'] ?></td>
                                                <td><?= $r1['15'] ?></td>
                                                <td><?= $r1['16'] ?></td>
                                                <td><?= $r1['17'] ?></td>
                                                <td><?= $r1['18'] ?></td>
                                                <td><?php if ($r1['19'] == 1) {
                                                        echo "Accepted";
                                                    } ?></td>

                                            </tr>
                                        </tbody>
                                    <?php
                                    }
                                    ?>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="container mt-5 mb-5">
                    <h1>Rejected</h1>
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive m-t-40">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>

                                            <th>fname</th>
                                            <th>lname</th>
                                            <th>father</th>
                                            <th>dob</th>
                                            <th>email</th>
                                            <th>snum</th>
                                            <th>pnum</th>
                                            <th>gender</th>
                                            <th>address</th>
                                            <th>pin</th>
                                            <th>state</th>
                                            <th>city</th>
                                            <th>conutry</th>
                                            <th>hobby</th>
                                            <th>courses</th>
                                            <th>result</th>
                                            <th>sphoto</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <?php
                                    foreach ($rows2 as $r2) {
                                    ?>
                                        <tbody>
                                            <tr>
                                                <td><?= $r2['2'] ?></td>
                                                <td><?= $r2['3'] ?></td>
                                                <td><?= $r2['4'] ?></td>
                                                <td><?= $r2['5'] ?></td>
                                                <td><?= $r2['6'] ?></td>
                                                <td><?= $r2['7'] ?></td>
                                                <td><?= $r2['8'] ?></td>
                                                <td><?= $r2['9'] ?></td>
                                                <td><?= $r2['10'] ?></td>
                                                <td><?= $r2['11'] ?></td>
                                                <td><?= $r2['12'] ?></td>
                                                <td><?= $r2['13'] ?></td>
                                                <td><?= $r2['14'] ?></td>
                                                <td><?= $r2['15'] ?></td>
                                                <td><?= $r2['16'] ?></td>
                                                <td><?= $r2['17'] ?></td>
                                                <td><?= $r2['18'] ?></td>
                                                <td><?php if ($r2['19'] == 2) {
                                                        echo "Rejected";
                                                    } ?></td>
                                            </tr>
                                        </tbody>
                                    <?php
                                    }
                                    ?>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </main>
        </div>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </div>
</body>

</html>