<?php
$id = $_REQUEST['id'];
$connection = mysqli_connect('localhost', 'root', '', 'college_admission');
$query = "UPDATE `form` SET `status` = '2' WHERE `form`.`id` = '$id';";
$result = $connection->query($query);
header('location: ../index.php')
?>
